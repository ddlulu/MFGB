
import numpy as np
from scipy import ndimage
from math import atan2, degrees, sqrt, radians, sin, cos
import matplotlib.pyplot as plt
from get_DEM_info import *
from error_def import *
# 新增依赖
from bayes_opt import BayesianOptimization
from sklearn.metrics import mean_squared_error, mean_absolute_error


PARAM_BOUNDS = {
    'slope_weight': ( , ),          
    'tpi_weight': ( , ),          
    'trd_weight': ( , ), 
    'roughness_weight': ( , ),   
    'ecv_weight': ( , ),          
    'kt_weight': ( , ),          
    'curvature_weight': ( , ),     
    'congestion_penalty_weight': ( , ), 
    'upstream_consistency_weight': ( , )
}

class FlowAgent:
    def __init__(self, i, j, dem, cell_size, initial_tca, agents_grid, slopes, tpis,trds, roughnesss, ecvs, kts, params=None):
        """
        水流代理类，代表单个网格单元的水流决策者

        参数：
            i, j: 网格坐标
            dem: 高程数据
            cell_size: 单元格大小
        """
        self.i = i
        self.j = j
        self.dem = dem
        self.cell_size = cell_size
        self.neighbors = []  
        self.weights = np.zeros(8)  
        self.prev_weights = None 
        self.tca = initial_tca  
        self.agents_grid = agents_grid  
       
        self.curvature_direction = Plan_curvature(dem, i, j, cell_size)  
        self.profile = Proflie_curvature(dem, i, j, cellsize)  
        self.tangential = Tangential(dem, i, j, cellsize)  
        
        self.historical_weights = np.zeros(8)  
        self.steep_slope_threshold = np.radians(median_value)  
        self.active_directions = []  
        self.prev_weights = None 

       
        self.slopes = slopes
        self.tpis = tpis
        self.trds = trds
        self.roughnesss = roughnesss
        self.ecvs = ecvs
        self.kts = kts

        
        default_params = {
            'slope_weight': 0.2,
            'tpi_weight': 0.2,
            'trd_weight': 0.2,
            'roughness_weight': 0.2,
            'ecv_weight': 0.2,
            'kt_weight': 0.2,
            'curvature_weight': 0.2,
            'congestion_penalty_weight': 0.2,
            'upstream_consistency_weight': 0.2
        }
        if params is None:
            params = default_params

        
        self.slope_weight = params.get('slope_weight', 0.2)
        self.tpi_weight = params.get('tpi_weight', 0.2)
        self.trd_weight = params.get('trd_weight', 0.2)
        self.roughness_weight = params.get('roughness_weight', 0.2)
        self.ecv_weight = params.get('ecv_weight', 0.2)
        self.kt_weight = params.get('kt_weight', 0.2)
        self.curvature_weight = params.get('curvature_weight', 0.2)
        self.congestion_penalty_weight = params.get('congestion_penalty_weight', 0.2)
        self.upstream_consistency_weight = params.get('upstream_consistency_weight', 0.2)


    def update_tca(self, new_tca):
        """更新代理的TCA引用"""
        self.tca = new_tca

    def _calculate_curvature_coherence(self, dirs, direction,i,j):
        """计算当前方向与曲率的匹配程度"""
        dir_angle = np.arctan2(dirs[direction][0], dirs[direction][1])  
        
        curvature_angle = self.aspect
        
        angle_diff = abs(dir_angle - curvature_angle) % (2 * np.pi)
        return np.cos(angle_diff)  


    def calculate_payoff(self, direction):
        
        dirs = [(0, 1), (1, 1), (1, 0), (1, -1),
                (0, -1), (-1, -1), (-1, 0), (-1, 1)]
        di, dj = dirs[direction]
        ni, nj = self.i + di, self.j + dj

        
        if ni < 0 or ni >= self.dem.shape[0] or nj < 0 or nj >= self.dem.shape[1]:
            return 0
        if dem[ni][nj] >= dem[self.i][self.j]:
            return 0

        
        if self.slopes[ni, nj] == -9999.0 and self.tpis[ni, nj] == -9999.0 and self.roughnesss[ni, nj] == -9999.0\
                 and self.ecvs[ni, nj] == -9999.0 and self.kts[ni, nj] == -9999.0:
            if dem[ni][nj] != -9999.0:
               
                payoff = (self.slope_weight * (dem[self.i][self.j] - dem[ni][nj]) / (di * di + dj * dj))
               
            else:
                return 0.01
        else:
           
            if dem[ni][nj] != -9999.0:
                
                payoff = self.slope_weight * payoff + self.tpi_weight * self.tpis[ni, nj] + self.roughness_weight * self.roughnesss[ni, nj] + self.ecv_weight * self.ecvs[ni, nj] + self.kt_weight * self.kts[ni, nj] + 10 * 1/dem[ni][nj]
               

       
        neighbor_weight = self.neighbors[direction].weights[direction] if self.neighbors[direction] else 0
        
        payoff += neighbor_weight
        
        downstream_tca = self.tca[ni, nj] if self.tca is not None else 0
        congestion_penalty = np.tanh(downstream_tca / cellsize**2) 
        payoff -= self.congestion_penalty_weight * congestion_penalty 
        if direction in [1, 3, 5, 7]:
            payoff -= 0.1 * congestion_penalty 
       
        opposite_dir = (direction + 4) % 8
        if self.neighbors[direction] is not None:
            neighbor = self.neighbors[direction]
            reverse_weight = neighbor.weights[opposite_dir]
            payoff *= (1 - 0.7 * reverse_weight) 
       
        upstream_consistency = 0
        n + 4) % 8
        di_rev, dj_rev = dirs[reverse_dir]
        max_trace_steps = 300 
        current_i, current_j = self.i, self.j
        for step in range(1, max_trace_steps + 1):
           
            ni = current_i + di_rev * step
            nj = current_j + dj_rev * step

            
            if ni < 0 or ni >= self.dem.shape[0] or nj < 0 or nj >= self.dem.shape[1]:
                break

            
            if self.dem[ni, nj] <= self.dem[current_i, current_j]:
                break

            
            upstream_agent = self.agents_grid[ni, nj]
            if upstream_agent is not None:
                
                if upstream_agent.weights[direction] > 0: 
                    upstream_consistency += 1
                else:
                    break  
            else:
                break

            current_i, current_j = ni, nj  

        payoff += self.upstream_consistency_weight * upstream_consistency  
        if self.tangential < 0:
            payoff += self.curvature_weight * self.curvature_direction
            payoff -= self.ecv_weight * self.profile
        else:
           
            flow_angle = np.arctan2(dirs[direction][1], dirs[direction][0])  # 注意坐标顺序
          
            angle_diff = abs(self.curvature_direction - flow_angle)
            cos_sim = np.cos(angle_diff)
           
            curvature_weight = 0.7 
            curvature_coef = curvature_weight * cos_sim + (1 - curvature_weight) * 1.0
            payoff += self.curvature_weight * curvature_coef



        return max(payoff, 0.01)

    def update_strategy(self):
        
        self.prev_weights = self.weights.copy() 
  

        self.historical_weights = 0.6 * self.historical_weights + 0.4 * self.weights
        new_weights_list = []
        for d in range(8):
            payoff = self.calculate_payoff(d) 
            new_weights_list.append(payoff)  
        new_weights = np.array(new_weights_list)

        total = np.sum(new_weights)
        self.prev_weights = self.weights.copy()
        self.weights = new_weights / total if total > 0 else np.zeros(8)



def calculate_curvature_direction(dem, i, j, cellsize):
    if i < 1 or i >= rows - 1 or j < 1 or j >= cols - 1:
        return 0.0 

    
    if (dem[i - 1, j - 1] == -9999 or dem[i - 1, j] == -9999 or
            dem[i - 1, j + 1] == -9999 or dem[i, j - 1] == -9999 or
            dem[i, j + 1] == -9999 or dem[i + 1, j - 1] == -9999 or
            dem[i + 1, j] == -9999 or dem[i + 1, j + 1] == -9999):
        return 0.0 

   
    fxx = (dem[i, j + 1] + dem[i, j - 1] - 2 * dem[i, j]) / (cellsize ** 2)
    fyy = (dem[i + 1, j] + dem[i - 1, j] - 2 * dem[i, j]) / (cellsize ** 2)
    fxy = (dem[i + 1, j + 1] - dem[i + 1, j - 1] - dem[i - 1, j + 1] + dem[i - 1, j - 1]) / (4 * cellsize ** 2)

   
    curvature_matrix = np.array([[fxx, fxy], [fxy, fyy]])
    
    eigenvalues, eigenvectors = np.linalg.eigh(curvature_matrix)

    
    if np.isclose(eigenvalues[0], eigenvalues[1], atol=1e-6):
        return 0.0 
    else:
        max_eigen_idx = np.argmax(eigenvalues)
        curvature_direction = np.arctan2(
            eigenvectors[1, max_eigen_idx],
            eigenvectors[0, max_eigen_idx]
        )
    return curvature_direction



class MultiFlowGame:
    def __init__(self, dem_data, cell_size, slopes, tpis, trds, roughnesss, ecvs, kts, params=None, max_iter=15, tolerance=1e-8):  # 原先tolerance=1e-4
       
        self.dem = dem_data.astype(float)
        self.rows, self.cols = self.dem.shape
        self.cell_size = cell_size
        self.max_iter = max_iter
        self.tolerance = tolerance
        self.prev_tca_variance = None  

       
        self.slopes = slopes
        self.tpis = tpis
        self.trds = trds
        self.roughnesss = roughnesss
        self.ecvs = ecvs
        self.kts = kts

        
        self.tca = np.where(self.dem == -9999.0, 0.0, self.cell_size ** 2)

        self.agents = np.empty((self.rows, self.cols), dtype=object)
        for i in range(self.rows):
            for j in range(self.cols):
                self.agents[i, j] = FlowAgent(i, j, self.dem, cell_size, self.tca, self.agents, slopes=self.slopes, tpis=self.tpis, trds=self.trds, roughnesss=self.roughnesss,
                                                  ecvs=self.ecvs, kts=self.kts, params=params)

        
        self._build_neighbor_relationships()

    def _build_neighbor_relationships(self):
        """建立代理之间的邻居关系"""
        dirs = [(0, 1), (1, 1), (1, 0), (1, -1),
                (0, -1), (-1, -1), (-1, 0), (-1, 1)]

        for i in range(self.rows):
            for j in range(self.cols):
                agent = self.agents[i, j]
                agent.neighbors = []
                for d, (di, dj) in enumerate(dirs):
                    ni, nj = i + di, j + dj
                    if 0 <= ni < self.rows and 0 <= nj < self.cols:
                        agent.neighbors.append(self.agents[ni, nj])
                    else:
                        agent.neighbors.append(None)

    
    def run_iteration(self):
        
        max_weight_change = 0.0 

      
        agent_list = [agent for agent in self.agents.flat if agent is not None]
        for agent in agent_list:
            if self.dem[agent.i][agent.j] != -9999.0:
                agent.update_strategy()  

       
        for agent in agent_list:
            if agent.prev_weights is not None:
                
                weight_change = np.max(np.abs(agent.weights - agent.prev_weights))
                max_weight_change = max(max_weight_change, weight_change)

       
        flow_directions = self.get_flow_directions()
        self.tca = compute_tca(flow_directions, self.dem, self.cell_size)

        
        for agent in self.agents.flat:
            if agent is not None:
                agent.update_tca(self.tca)

        return max_weight_change  
    def solve_equilibrium(self):
        
        for iter in range(self.max_iter):
            current_max_change = self.run_iteration() 

        
            if iter == 0:
                prev_max_change = current_max_change
                continue

           
            print(f"Iter {iter:03d}: Max Weight Change = {current_max_change:.6f}")

           
            if current_max_change < self.tolerance:
                print(f"策略稳定于迭代 {iter}, 最大权重变化: {current_max_change:.2e}")
                return

            prev_max_change = current_max_change

        print(f"达到最大迭代次数 {self.max_iter}")
    
    def get_flow_directions(self):
        
        flow_directions = np.zeros((self.rows, self.cols, 8))
        for i in range(self.rows):
            for j in range(self.cols):
                flow_directions[i, j] = self.agents[i, j].weights
        return flow_directions
class OptimizedMultiFlowGame(MultiFlowGame):
    def __init__(self, dem_data, cell_size, slopes, tpis, trds, roughnesss, ecvs, kts, params1, params2):
        
        super().__init__(
            dem_data=dem_data,
            cell_size=cell_size,
            slopes=slopes,
            tpis=tpis,
            trds=trds,
            roughnesss=roughnesss,
            ecvs=ecvs,
            kts=kts,
            params=None 
        )
       
        self.params1 = params1
        self.params2 = params2

       
        for i in range(self.rows):
            for j in range(self.cols):
                agent = self.agents[i, j]
                if agent is not None:
                    
                    if agent.tangential < 0:
                        self._apply_params(agent, params1)
                    else:  
                        self._apply_params(agent, params2)

    def _apply_params(self, agent, params):
        
        agent.slope_weight = params.get('slope_weight')
        agent.tpi_weight = params.get('tpi_weight')
        agent.trd_weight = params.get('trd_weight')
        agent.roughness_weight = params.get('roughness_weight')
        agent.ecv_weight = params.get('ecv_weight')
        agent.kt_weight = params.get('kt_weight')
        agent.curvature_weight = params.get('curvature_weight')
        agent.congestion_penalty_weight = params.get('congestion_penalty_weight')
        agent.upstream_consistency_weight = params.get('upstream_consistency_weight')
def objective_function(params, dem_data, tca_theory,
                       slopes, tpis, trds, roughnesss, ecvs, kts):
    
    try:
       
        params = {
            'slope_weight': float(params['slope_weight']),
            'tpi_weight': float(params['tpi_weight']),
            'trd_weight': float(params['trd_weight']),
            'roughness_weight': float(params['roughness_weight']),
            'ecv_weight': float(params['ecv_weight']),
            'kt_weight': float(params['kt_weight']),
            'curvature_weight': float(params['curvature_weight']),
            'congestion_penalty_weight': float(params['congestion_penalty_weight']),
            'upstream_consistency_weight': float(params['upstream_consistency_weight'])
        }
        
        game = OptimizedMultiFlowGame(
            dem_data=dem_data,
            cell_size=cellsize,
            slopes=slopes,
            tpis=tpis,
            trds=trds,
            roughnesss=roughnesss,
            ecvs=ecvs,
            kts=kts,
            params=params
        )

        
        game.solve_equilibrium()

        
        tca_simulated = game.tca

       
        mask = (tca_theory != -9999) & (tca_simulated != -9999)
        rmse = np.sqrt(mean_absolute_error(
            tca_theory[mask],
            tca_simulated[mask]
        ))
        return -rmse  

    except Exception as e:
        print(f"Error in evaluation: {str(e)}")
        return -9999  



def optimize_parameters(dem, tca_theory,
                        slopes, tpis, trds, roughnesss, ecvs, kts,
                        init_points=5, n_iter=15):
    
    def wrapped_func(**params):
        return objective_function(params, dem, tca_theory,
                                  slopes, tpis, trds, roughnesss, ecvs, kts)

   
    optimizer = BayesianOptimization(
        f=wrapped_func,
        pbounds=PARAM_BOUNDS,
        random_state=42,
    )

   
    optimizer.maximize(init_points=init_points, n_iter=n_iter)

    
    best_params = optimizer.max['params']
    print(f"\n最佳参数组合：")
    for k, v in best_params.items():
        print(f"{k}: {v:.4f}")

    return best_params


def calculate_gradient_angle(dem, i, j, cellsize):
    
    fx = (dem[i, j+1] - dem[i, j-1]) / (2 * cellsize)  
    fy = (dem[i+1, j] - dem[i-1, j]) / (2 * cellsize)  
    gradient_angle = np.arctan2(fy, fx)  
    return gradient_angle



def compute_tca(flow_directions, dem, cell_size):
    
    rows, cols = dem.shape
    tca = np.where(dem == -9999, 0.0, cell_size ** 2)
    dx = [0, 1, 1, 1, 0, -1, -1, -1]
    dy = [1, 1, 0, -1, -1, -1, 0, 1]

    
    cells = sorted([(dem[i, j], i, j) for i in range(rows) for j in range(cols) if dem[i, j] != -9999],
                   reverse=True)

    for _, i, j in cells:
        for d in range(8):
            ni, nj = i - dx[d], j - dy[d]
            if 0 <= ni < rows and 0 <= nj < cols:
                tca[i, j] += tca[ni, nj] * flow_directions[ni, nj, d]
    return tca

def plot_accumulation_distribution(accumulation, path, title):
    
    accumulation = accumulation.astype(float)

   
    accumulation[accumulation < -7000] = np.nan
    plt.figure(figsize=(10, 8))
    plt.imshow(accumulation, cmap='jet', interpolation='nearest')  
    plt.colorbar(label='Accumulation Value') 
    plt.title(title)
    plt.xlabel('Column Index')
    plt.ylabel('Row Index')
    plt.savefig(path)
    plt.show()

def fill_sink(dem_f):
    max_val = 100000.0
    rows,cols = dem_f.shape
    for i in range(2, rows - 2):
        for j in range(2, cols - 2):
            if dem_f[i][j] == -9999.0:
                continue

          
            if (dem_f[i - 1][j - 1] == -9999.0 or dem_f[i - 1][j] == -9999.0 or dem_f[i - 1][j + 1] == -9999.0 or
                    dem_f[i][j + 1] == -9999.0 or dem_f[i + 1][j + 1] == -9999.0 or dem_f[i + 1][j] == -9999.0 or
                    dem_f[i + 1][j - 1] == -9999.0 or dem_f[i][j - 1] == -9999.0):
                continue
            
            min_val = max_val
            min_val = min(min_val, dem_f[i - 1][j - 1])
            min_val = min(min_val, dem_f[i - 1][j])
            min_val = min(min_val, dem_f[i - 1][j + 1])
            min_val = min(min_val, dem_f[i][j + 1])
            min_val = min(min_val, dem_f[i + 1][j + 1])
            min_val = min(min_val, dem_f[i + 1][j])
            min_val = min(min_val, dem_f[i + 1][j - 1])
            min_val = min(min_val, dem_f[i][j - 1])
            
            if min_val > dem_f[i][j]:
                old = dem_f[i][j]
                dem_f[i][j] = min_val
    return dem_f

if __name__ == "__main__":
   
    O_dem = np.loadtxt('your_dir')  
    
    cellsize = 2.5  # your resolution

    height, width = O_dem.shape

    plot_accumulation_distribution(O_dem, 'dem_saddle', 'dem_saddle')

   
    rows, cols = height + 4, width + 4
    dem = np.full((rows, cols), -9999.0)  

    dem[2:-2, 2:-2] = O_dem


    SLOPES = np.full((rows, cols), -9999.0)
    TPIS = np.full((rows, cols), -9999.0)
    TRDS = np.full((rows, cols), -9999.0)
    ECVS = np.full((rows, cols), -9999.0)
    ROUGHNESS = np.full((rows, cols), -9999.0)
    TANGENTIAL_CURTURES = np.full((rows, cols), -9999.0)
    for i in range(rows):
        for j in range(cols):
            value = dem[i][j]
            if value != -9999:
                center_pixel = value
                SLOPES[i][j] = get_slope(dem, i, j, cellsize)
                TPIS[i][j] = get_tpi(dem, i, j, cellsize)
                TRDS[i][j] = get_TRD(dem, i, j, cellsize)
                ECVS[i][j] = get_CEV(dem, i, j, cellsize)
                ROUGHNESS[i][j] = get_roughess(dem, i, j, cellsize)
                TANGENTIAL_CURTURES[i][j] = Tangential(dem, i, j, cellsize)
               
    
    valid_data = SLOPES[SLOPES != -9999.0]

    if valid_data.size == 0:
        
        median_value = None  
    else:
        median_value = np.median(valid_data)

   
    final_game = OptimizedMultiFlowGame(
        dem_data=dem,
        cell_size=cellsize,
        slopes=SLOPES,
        tpis=TPIS,
        trds=TRDS,
        roughnesss=ROUGHNESS,
        ecvs=ECVS,
        kts=TANGENTIAL_CURTURES,
        params1=best_params_1,   
        params2=best_params_2     
    )
    final_game.solve_equilibrium()

  
    flow_directions = final_game.get_flow_directions()

 
    tca = compute_tca(flow_directions, dem, cellsize)

    tca[dem == -9999.0] = -9999.0

  
    for i in range(1, rows-1):
        for j in range(1, cols-1):
          
            if (dem[i - 1, j] == -9999.0 or
                    dem[i + 1, j] == -9999.0 or
                    dem[i, j - 1] == -9999.0 or
                    dem[i, j + 1] == -9999.0 or
                    dem[i - 1, j - 1] == -9999.0 or
                    dem[i - 1, j + 1] == -9999.0 or
                    dem[i + 1, j - 1] == -9999.0 or
                    dem[i + 1, j + 1] == -9999.0):
                if tca[i, j] != -9999:
                    tca[i, j] = -9999.0
   

    plot_accumulation_distribution(tca, 'save_path', 'save_name')

   

