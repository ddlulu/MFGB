

1. the analytical DEMs and theoretical TCA arrays used in the paper; or
2. a deterministic script that regenerates those analytical surfaces and their
   theoretical TCA values.

Recommended layout:

```text
data/
  analytical/
    ellipsoid/
    inverse_ellipsoid/
    plane/
    saddle/
```real_dem

Do not upload restricted or third-party data without permission.
