# MFGB — Multi-Factor Game-Based DEM Flow Routing

This repository package reorganizes the supplied MFGB research code into a
traceable structure suitable for preparing a public computational-geoscience
release.

> **Important:** this package deliberately does not claim that the repository
> is publication-ready yet. The source audit identified several manuscript/code
> consistency issues that should be resolved first. See
> `docs/CODE_AUDIT.md`.

## Repository structure

```text
MFGB_CG_code_release/
├── src/mfgb/                  # cleaned, importable core
│   ├── core.py
│   ├── metrics.py
│   └── optimization.py
├── legacy/                    # original supplied research scripts, unchanged
├── configs/                   # parameter bounds
├── examples/                  # self-contained smoke test
├── tests/                     # minimal automated tests
├── data/                      # instructions for benchmark data
├── docs/
│   ├── CODE_AUDIT.md
│   ├── METHOD_CODE_MAP.md
│   └── RELEASE_CHECKLIST.md
├── requirements.txt
├── environment.yml
├── CITATION.cff
└── LICENSE_TEMPLATE_MIT.txt
```

## What was changed

The cleaned `src/mfgb` package removes hard-coded local paths and global state,
separates routing, metrics, and calibration, and accepts terrain attributes as
precomputed arrays. The original scripts are retained unchanged in `legacy/`
so every refactoring decision can be checked against the research source.

No published benchmark values or algorithmic choices were silently replaced.
Where the source code and recent manuscript description appear inconsistent,
the issue is documented in `docs/CODE_AUDIT.md` instead of being guessed.

## Installation

Using Conda:

```bash
conda env create -f environment.yml
conda activate mfgb
```

or using pip in a clean Python environment:

```bash
pip install -r requirements.txt
```

## Smoke test

```bash
python examples/smoke_test.py
```

The smoke test uses a tiny synthetic tilted surface only to verify that the
cleaned routing core runs. It does **not** reproduce the article results.

Run tests with:

```bash
pytest -q
```

## Paper-result reproduction

The benchmark DEMs, theoretical TCA arrays, and the exact terrain-attribute
preprocessing module were not included in the files supplied for this cleanup.
Therefore, full paper reproduction is not yet possible from this archive alone.
Before public release, add those materials and scripts that reproduce the main
figures/tables. See `data/README.md` and `docs/RELEASE_CHECKLIST.md`.

## Code availability statement template

> The source code and configuration files for MFGB are available at
> **[PUBLIC REPOSITORY URL]**. The repository includes the routing
> implementation, parameter settings, environment specification, example data,
> and scripts required to reproduce the reported analytical benchmarks.

Use that statement only after the repository actually contains the claimed
materials.

## License

A MIT license template is included as `LICENSE_TEMPLATE_MIT.txt` for review.
The authors should make the licensing decision and rename the approved license
file to `LICENSE` before public release.
