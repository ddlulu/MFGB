"""Small self-contained smoke test.

This example verifies that the cleaned MFGB core executes. It is NOT a
reproduction of the paper benchmark because the paper's terrain-attribute
preprocessing functions/data were not part of the supplied files.
"""

import os
import sys
import numpy as np

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(ROOT, "src"))

from mfgb import MFGBModel

# A small tilted surface: elevation decreases toward the southeast.
y, x = np.mgrid[0:12, 0:12]
dem = 100.0 - 2.0 * y - 1.0 * x
cell_size = 1.0

# Simple demonstration inputs only.
gy, gx = np.gradient(dem, cell_size)
slopes = np.hypot(gx, gy)
curvature_direction = np.zeros_like(dem)

model = MFGBModel(
    dem=dem,
    cell_size=cell_size,
    slopes=slopes,
    curvature_direction=curvature_direction,
    max_iter=5,
    tolerance=1e-6,
).fit()

print("iterations_run:", model.iterations_run)
print("converged:", model.converged)
print("TCA shape:", model.tca.shape)
print("TCA finite:", np.isfinite(model.tca).all())
print("max TCA:", float(model.tca.max()))
