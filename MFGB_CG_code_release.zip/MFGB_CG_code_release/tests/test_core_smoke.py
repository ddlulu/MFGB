import os
import sys
import numpy as np

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(ROOT, "src"))

from mfgb import MFGBModel, calculate_metrics


def test_core_executes():
    y, x = np.mgrid[0:6, 0:6]
    dem = 50.0 - y - x
    gy, gx = np.gradient(dem)
    slopes = np.hypot(gx, gy)
    curvature = np.zeros_like(dem)
    model = MFGBModel(dem, 1.0, slopes, curvature, max_iter=2).fit()
    assert model.tca.shape == dem.shape
    assert np.isfinite(model.tca).all()


def test_metrics():
    ref = np.array([1.0, 2.0, 3.0])
    pred = np.array([1.0, 2.1, 2.9])
    out = calculate_metrics(pred, ref)
    assert out["RMSE"] >= 0
    assert out["sMAPE"] >= 0
