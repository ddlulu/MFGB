"""Core MFGB routing implementation.

This module is a cleaned extraction of the active routing logic in the
analytical research script. It removes hard-coded file paths and global state.
Terrain attributes are supplied as precomputed arrays so that feature
construction can be documented and tested separately.

Important: see docs/CODE_AUDIT.md before using this package for a paper release.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional, Tuple

import numpy as np

DIRS: Tuple[Tuple[int, int], ...] = (
    (0, 1), (1, 1), (1, 0), (1, -1),
    (0, -1), (-1, -1), (-1, 0), (-1, 1),
)
INVALID = -9999.0


@dataclass
class MFGBParameters:
    """MFGB parameter container.

    
    """
    # 默认参数，具体运行时需调整
    slope_weight: float = 0.2
    tpi_weight: float = 0.2
    trd_weight: float = 0.2
    roughness_weight: float = 0.2
    ecv_weight: float = 0.2
    kt_weight: float = 0.2
    curvature_weight: float = 0.2
    congestion_penalty_weight: float = 0.2
    upstream_consistency_weight: float = 0.2

    @classmethod
    def from_dict(cls, params: Optional[Dict[str, float]]) -> "MFGBParameters":
        if params is None:
            return cls()
        defaults = cls()
        values = {name: float(params.get(name, getattr(defaults, name)))
                  for name in cls.__dataclass_fields__}
        return cls(**values)

    def as_dict(self) -> Dict[str, float]:
        return {name: float(getattr(self, name)) for name in self.__dataclass_fields__}


def compute_tca(flow_directions: np.ndarray, dem: np.ndarray, cell_size: float,
                cells_sorted=None) -> np.ndarray:
    """Compute total contributing area from an 8-direction allocation field."""
    rows, cols = dem.shape
    tca = np.where(dem == INVALID, 0.0, cell_size ** 2).astype(float)

    if cells_sorted is None:
        cells_sorted = sorted(
            [(dem[i, j], i, j) for i in range(rows) for j in range(cols)
             if dem[i, j] != INVALID],
            reverse=True,
        )

    for _, i, j in cells_sorted:
        for d, (di, dj) in enumerate(DIRS):
            ni, nj = i - di, j - dj
            if 0 <= ni < rows and 0 <= nj < cols:
                tca[i, j] += tca[ni, nj] * flow_directions[ni, nj, d]
    return tca


class _FlowAgent:
    def __init__(
        self,
        i: int,
        j: int,
        model: "MFGBModel",
    ) -> None:
        self.i = i
        self.j = j
        self.model = model
        self.weights = np.zeros(8, dtype=float)
        self.prev_weights: Optional[np.ndarray] = None
        self.neighbors = [None] * 8

    def calculate_payoff(self, direction: int) -> float:
        m = self.model
        dem = m.dem
        di, dj = DIRS[direction]
        ni, nj = self.i + di, self.j + dj

        # Invalid or non-downslope directions receive zero allocation.
        if not (0 <= ni < m.rows and 0 <= nj < m.cols):
            return 0.0
        if dem[ni, nj] == INVALID or dem[ni, nj] >= dem[self.i, self.j]:
            return 0.0

        # Preserve the active analytical-source logic.
        feature_missing = (
            m.slopes[ni, nj] == INVALID
            and m.tpis[ni, nj] == INVALID
            and m.roughness[ni, nj] == INVALID
            and m.ecvs[ni, nj] == INVALID
            and m.kts[ni, nj] == INVALID
        )
        if feature_missing:
            drop = dem[self.i, self.j] - dem[ni, nj]
            payoff = (
                m.params.slope_weight * drop / (di * di + dj * dj)
                + 10.0 * drop
            )
        else:
            payoff = m.params.slope_weight * m.slopes[ni, nj]

        # Neighbor same-direction interaction.
        neighbor = self.neighbors[direction]
        neighbor_weight = neighbor.weights[direction] if neighbor is not None else 0.0
        payoff += neighbor_weight

        # Accumulation-dependent congestion penalty.
        downstream_tca = m.tca[ni, nj]
        congestion = np.tanh(downstream_tca / (m.cell_size ** 2))
        payoff -= m.params.congestion_penalty_weight * congestion
        if direction in (1, 3, 5, 7):
            payoff -= 0.1 * congestion

        # Reverse-direction competition.
        if neighbor is not None:
            opposite = (direction + 4) % 8
            reverse_weight = neighbor.weights[opposite]
            payoff *= (1.0 - 0.7 * reverse_weight)

        # Upstream path consistency. This intentionally preserves the stepping
        # pattern of the current analytical script for traceability.
        upstream_consistency = 0
        reverse_dir = (direction + 4) % 8
        di_rev, dj_rev = DIRS[reverse_dir]
        current_i, current_j = self.i, self.j
        for step in range(1, m.max_trace_steps + 1):
            ui = current_i + di_rev * step
            uj = current_j + dj_rev * step
            if not (0 <= ui < m.rows and 0 <= uj < m.cols):
                break
            if dem[ui, uj] <= dem[current_i, current_j]:
                break
            upstream_agent = m.agents[ui, uj]
            if upstream_agent is None or upstream_agent.weights[direction] <= 0:
                break
            upstream_consistency += 1
            current_i, current_j = ui, uj
        payoff += m.params.upstream_consistency_weight * upstream_consistency

        # Curvature-direction consistency.
        flow_angle = np.arctan2(dj, di)
        angle_diff = abs(m.curvature_direction[self.i, self.j] - flow_angle)
        curvature_coef = 0.7 * np.cos(angle_diff) + 0.3
        payoff += m.params.curvature_weight * curvature_coef

        # Current research code floors valid-direction payoff at 0.01.
        return max(float(payoff), 0.01)

    def update_strategy(self) -> None:
        self.prev_weights = self.weights.copy()
        scores = np.array([self.calculate_payoff(d) for d in range(8)], dtype=float)
        total = float(scores.sum())
        self.weights = scores / total if total > 0.0 else np.zeros(8, dtype=float)


class MFGBModel:
    """Clean MFGB routing model using precomputed terrain arrays.

    The update is asynchronous in deterministic raster order, matching the
    current analytical research script. Convergence is measured by change in
    TCA variance, also matching that script.
    """

    def __init__(
        self,
        dem: np.ndarray,
        cell_size: float,
        slopes: np.ndarray,
        curvature_direction: np.ndarray,
        tpis: Optional[np.ndarray] = None,
        trds: Optional[np.ndarray] = None,
        roughness: Optional[np.ndarray] = None,
        ecvs: Optional[np.ndarray] = None,
        kts: Optional[np.ndarray] = None,
        params: Optional[Dict[str, float]] = None,
        max_iter: int = 100,
        tolerance: float = 1e-4,
        max_trace_steps: int = 300,
    ) -> None:
        self.dem = np.asarray(dem, dtype=float)
        self.cell_size = float(cell_size)
        self.rows, self.cols = self.dem.shape
        self.slopes = np.asarray(slopes, dtype=float)
        self.curvature_direction = np.asarray(curvature_direction, dtype=float)
        shape = self.dem.shape
        self.tpis = np.full(shape, INVALID) if tpis is None else np.asarray(tpis, dtype=float)
        self.trds = np.full(shape, INVALID) if trds is None else np.asarray(trds, dtype=float)
        self.roughness = np.full(shape, INVALID) if roughness is None else np.asarray(roughness, dtype=float)
        self.ecvs = np.full(shape, INVALID) if ecvs is None else np.asarray(ecvs, dtype=float)
        self.kts = np.full(shape, INVALID) if kts is None else np.asarray(kts, dtype=float)
        self.params = MFGBParameters.from_dict(params)
        self.max_iter = int(max_iter)
        self.tolerance = float(tolerance)
        self.max_trace_steps = int(max_trace_steps)

        for name, arr in {
            "slopes": self.slopes,
            "curvature_direction": self.curvature_direction,
            "tpis": self.tpis,
            "trds": self.trds,
            "roughness": self.roughness,
            "ecvs": self.ecvs,
            "kts": self.kts,
        }.items():
            if arr.shape != shape:
                raise ValueError(f"{name} shape {arr.shape} does not match DEM shape {shape}")

        self.tca = np.where(self.dem == INVALID, 0.0, self.cell_size ** 2).astype(float)
        self.agents = np.empty(shape, dtype=object)
        for i in range(self.rows):
            for j in range(self.cols):
                self.agents[i, j] = None if self.dem[i, j] == INVALID else _FlowAgent(i, j, self)

        for i in range(self.rows):
            for j in range(self.cols):
                agent = self.agents[i, j]
                if agent is None:
                    continue
                neighbors = []
                for di, dj in DIRS:
                    ni, nj = i + di, j + dj
                    neighbors.append(self.agents[ni, nj] if 0 <= ni < self.rows and 0 <= nj < self.cols else None)
                agent.neighbors = neighbors

        self.agent_list = [a for a in self.agents.flat if a is not None]
        self.valid_cells_sorted = sorted(
            [(self.dem[i, j], i, j) for i in range(self.rows) for j in range(self.cols)
             if self.dem[i, j] != INVALID],
            reverse=True,
        )
        self.prev_tca_variance: Optional[float] = None
        self.iterations_run = 0
        self.converged = False

    def get_flow_directions(self) -> np.ndarray:
        flow = np.zeros((self.rows, self.cols, 8), dtype=float)
        for agent in self.agent_list:
            flow[agent.i, agent.j] = agent.weights
        return flow

    def run_iteration(self) -> float:
        # Asynchronous, deterministic raster-order updates.
        for agent in self.agent_list:
            agent.update_strategy()

        self.tca = compute_tca(
            self.get_flow_directions(), self.dem, self.cell_size, self.valid_cells_sorted
        )
        valid = self.tca[self.dem != INVALID]
        return float(np.var(valid)) if valid.size else 0.0

    def fit(self) -> "MFGBModel":
        self.prev_tca_variance = None
        self.converged = False
        for it in range(self.max_iter):
            current_variance = self.run_iteration()
            self.iterations_run = it + 1
            if self.prev_tca_variance is not None:
                if abs(current_variance - self.prev_tca_variance) < self.tolerance:
                    self.converged = True
                    break
            self.prev_tca_variance = current_variance
        return self
