"""Bayesian calibration helpers for MFGB.

The current analytical research script calibrates against RMSE in log1p(TCA),
i.e. RMSLE. This module preserves that objective by default. See CODE_AUDIT.md.
"""

from __future__ import annotations

from typing import Dict, Optional
import numpy as np

from .core import MFGBModel




def calibration_loss_rmsle(simulated: np.ndarray, reference: np.ndarray, invalid: float = -9999.0) -> float:
    mask = (simulated != invalid) & (reference != invalid) & np.isfinite(simulated) & np.isfinite(reference)
    s = np.maximum(simulated[mask], 0.0)
    r = np.maximum(reference[mask], 0.0)
    return float(np.sqrt(np.mean((np.log1p(s) - np.log1p(r)) ** 2)))


def optimize_parameters(
    model_kwargs: Dict,
    tca_reference: np.ndarray,
    bounds: Optional[Dict[str, tuple]] = None,
    init_points: int = 30,
    n_iter: int = 90,
    random_state: int = 42,
) -> Dict[str, float]:
    """Run Bayesian optimization using the source-code calibration objective."""
    try:
        from bayes_opt import BayesianOptimization
    except ImportError as exc:
        raise ImportError("Install bayesian-optimization to use optimize_parameters().") from exc

    pbounds = PARAM_BOUNDS if bounds is None else bounds

    def objective(**params):
        model = MFGBModel(params=params, **model_kwargs).fit()
        return -calibration_loss_rmsle(model.tca, tca_reference)

    optimizer = BayesianOptimization(
        f=objective,
        pbounds=pbounds,
        random_state=random_state,
        verbose=2,
        allow_duplicate_points=True,
    )
    optimizer.maximize(init_points=int(init_points), n_iter=int(n_iter))
    return {k: float(v) for k, v in optimizer.max["params"].items()}
